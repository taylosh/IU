#!/usr/bin/env python3
"""
Programming HW2: LTI Systems and Convoluation
"""
import numpy as np
import math
import soundfile

def convolve(x, h):
    """
    Implement convolution,
    :param x: Input signal
    :param h: system impusle response
    :return: Full convolution
    """
    pass




if  __name__ == "__main__":
    ### Convovle the excitation signal with the vocal tract impulse responses to get a vowel
    pass


    ### Convolve the anechoic speech with the room impulse responses to get the reverberation effects
