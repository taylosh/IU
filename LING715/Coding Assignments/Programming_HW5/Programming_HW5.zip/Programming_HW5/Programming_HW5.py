#!/usr/bin/env python3
"""
Programming HW5: Spectrogram
"""

import numpy as np
import math
import matplotlib.pyplot as plt
import soundfile as sf

def spectrogram(sig, sr, win_len=0.025, frame_len=0.01, window_fn=np.hamming):
    '''

    :param sig: input 1D NumPy array representing the audio waveform
    :param sr: sampling rate (Hz)
    :param win_len: window length in seconds
    :param frame_len: frame step in seconds
    :param window_fn:window function generator, such as np.hamming
    :return:
    ;param spec: 2D NumPy array of shape (num_freq_bins, num_frames) — the magnitude of the DFT
    ;param t: 1D array of time stamps for each frame
    ;param f: 1D array of frequency stamps
    '''


    pass









if __name__ == "__main__":

    ### Read the sound file
    sig, sr = sf.read("sample.wav")

    ### Plot the spectrogram
    spec, t, f = spectrogram(sig, sr, win_len=0.025, frame_len=0.01, window_fn=np.hamming)
    plt.figure(figsize=(16, 10))
    plt.imshow(20 * np.log10(np.abs(spec) + 1e-10), aspect='auto', origin='lower', extent=[t[0], t[-1], f[0], f[300]])
    plt.title("Spectrogram with Hamming window)")
    plt.xlabel("Time [s]")
    plt.ylabel("Frequency [Hz]")
    plt.colorbar(label="Magnitude [dB]")