#!/usr/bin/env python3
"""
LING545/CS659 A0: Basic Text Processing
@author: Shuju Shi
"""
import collections
import numpy as np

def word_freq(input, output):
    '''
    Open the file specified by the input,
    and split the text into individual words.
    Count the frequency of each word,
    and save the results to the output file.
    The output file should follow this format:"

    Young   1
    people  3
    '''
    ### Start your implementation here.
    pass
if __name__ == '__main__':
    input = "./ets_sample_l2_writing.txt"
    output = "./words_freq.txt"
    word_freq(input, output)
